
# FNO evaluation for PIC in 1D on NVIDIA A100-SXM4-40GB

## Simulation Configuration

| Parameter | Value |
|-----------|-------|
| kc           | 0.5 |
| NG           | 32 |
| T            | 30.0 |
| dt           | 0.05 |
| alpha        | 0.05 |
| Vt           | 1 |
| nParticle    | 100000 |
| Qm           | -1 |
| checkpoint   | model_epoch250.pt |
| runId        | 1 |
| imgExt       | png |
| evalDir      | /p/home/jusers/mamic1/jureca/operator_learning_stuff/3D_electrostatic_plasma/mamic1_test/inference_testing/eval_test_stuff/weakLandauAfterMultipleT10oneload/weakLandau |
| dim          | 3 |
| predOnly     | False |
| testCase     | weakLandau |
| ref          | pif |
| model_dtype  | float32 |
| fno_dtype    | float32 |
| tp_size      | 4 |
| config       | test_inference.yaml |


Plots :

- [Energy](weakLandau_Energy_run1.png)
- [Conservation Errors](weakLandau_conservation_errors_run1.png)
- [Landau decay](None)
- [Growth rate](None)

Average time for Accleration per timestep in PIC (millisec): 21.617
Average Inference time for Accleration using FNO (millisec): 121.247
Speed up PIC/FNO: 0.178
