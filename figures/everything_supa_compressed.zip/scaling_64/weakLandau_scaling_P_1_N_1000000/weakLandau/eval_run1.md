
# FNO evaluation for PIC in 1D on NVIDIA A100-SXM4-40GB

## Simulation Configuration

| Parameter | Value |
|-----------|-------|
| kc           | 0.5 |
| NG           | 32 |
| T            | 20.0 |
| dt           | 0.05 |
| alpha        | 0.05 |
| Vt           | 1 |
| nParticle    | 1000000 |
| Qm           | -1 |
| checkpoint   | model_epoch250.pt |
| runId        | 1 |
| imgExt       | png |
| evalDir      | /p/home/jusers/mamic1/jureca/operator_learning_stuff/3D_electrostatic_plasma/mamic1_test/inference_testing/eval_test_stuff/scaling_64/weakLandau_scaling_P_1_N_1000000/weakLandau |
| dim          | 3 |
| predOnly     | True |
| testCase     | weakLandau |
| ref          | pif |
| model_dtype  | float64 |
| fno_dtype    | float64 |
| tp_size      | 1 |
| config       | generated_configs/combined_N1000000_P1.yaml |


Plots :

- [Energy](weakLandau_Energy_run1.png)
- [Conservation Errors](weakLandau_conservation_errors_run1.png)
- [Landau decay](None)
- [Growth rate](None)

Average time for Accleration per timestep in PIC (millisec): None
