# data
## transforms
### vandermonde_matrix_free.py
    - Never constructs the entire matrix
    - Separates the D-dim phase between axes (p_n . f_k = p_n,x * f_k,x + ...
    - The full transform kernel is a PRODUCT of exponentials, one factor per axis: e^(2*pi*i*p_n.f_k) ...


### vandermonde.py
    - self.X_ = torch.cat(...
        - Builds signed frequencies length m
        - .repeat(self.batch_size, 1) -> converts it from a (2kX, ) size array to a (batch_size, 2kX) matrix - copies the same
        frequency list for every item in the batch. Needed for torch.bmm (batched matrix multiply) requires every operand
        to carry explicit batch dimension, even though requency values don't differ across the batch, only positions do.
        - Then [:,:,None] -> adds a trailing size-1 dimension, so the final shape is (batch_size, 2kX, 1) - again so that
        torch.bmm(self.X_, xpos[:, None, :]) works, it requires shapes (B, n, k) x (B, k, m) -> (B, n, m), and here
        self.X_ is (B, 2kX, 1) and xpos[:, None, :] is (B, 1, N) -> product is (B, 2kX, N).
        This way you get all phase values in one batched matrix op instead of looping.
    - phase = X[...] + Y[...] 
    - forward_mat = ...
        - This is for 2D/3D, the mod-sum-times-Pk in paper Eq (5)
        - Except it doesn-t do a single row index j and decodes it into (k_1, k_2) (,k_3), it instead
        via PyTorch builds the (2k_X, 2k_Z, N) tensor via the broadcasting in X + Y, which gives you every
        2k_X * 2k_Y combination, then reshapes(...) it flattening the 2 mode axes into one. Same thing as in paper
        only done with PyTorch flattening.

# layers
### dse.py
    - implements the Direct Spectral Evaluation approach from the NUDFT_FNO paper
    - sets up the learnable weights self.R, initialized as rand(dv, dv, 2*self.kX, 2*self.kY...) * scale
    - scale is 1/(dv*dv) to curb large values, standard
    - here dv is the number of channels - phyisical field values per particle, like velocity, density, ...
    - and 2*kDim - for every one of the m=2*Dim modes, there is a separate learnable dv x dv complex weight matrix
    - ANALOGOUS to FNO spectral weight tensor - model learns a different linear transform of the channels FOR EACH FREQUENCY
    - because convolution in physical space is multiplication in Fourier space... This learns the convolution in Fourier domain

    - in compl_mul - the real stuff:  return einsum_fn("bik,iok->bok", input, R) is the convolution in fourier space (multiplication)
    - input data is shape (batchsize, dv, 2*kX, 2*kY, ...), weights shape (dv, dv, 2*kX, 2*kY, ...)
    - reduction in einsum is always reducing on the dv dimension of shape (2nd of both), that is
    - output[b,o,k] = sum_i (input[b,i,k] * R[i,o,k])     --> independent for each mode k !!
    - interpretation: for every mode k, take the all input channels, mix them together using the learned weight matrix dv x dv
    - which produces output channels... THIS IS THE LEARNED PART / THE FORWARD TRASNFORM OF THE MODEL !!!

    - now in forward(self, x, transform) - the transform you choose, for the particle in cell use VandermondeTransform
    - then transform.forward(x)
    - and then the particle-parallel part - all_reduce if tp_size > 1 - since X_k (x converted to frequency mode k in Four. domain)
    - is a sum over all particles, each GPU holds a shard of particles, computes its own partial sum in transform.forward()
    - and then all_reduce sums all the partial sums together to get the total x_ft

    - then in the fourier domain we do the convolution - here multiplication: out_ft = self.compl_mult(x_ft, self.R)
    - which is applying the learned spectral convolution filter
    - then we go back to the physical space via inverse transform...
    - then we normalize, we multiply with factor D/N not square root of it like in the paper
    - and we return the real part x.real - we used complex numbers cause we need it for Fourier... but it should be near 0 complex part, since particle data is physically real-valued.

    - now the DSELayer class - 1 Fourier layer
    - the activation function is ReLU by default, and you can choose GeLU (Gaussian Error Linear Unit)
    - FNO paper: https://arxiv.org/pdf/2010.08895
    - you do the spectral convolution of your input data (with the first m modes for each dimension, the global patterns)
    - simultaneously on the same input data you push it through an MLP (local linear transform, fine details)
    - then you return sigma(convolved + MLP output)
    - thats it :)

# model
### fno.py
    - this is where the DSELayers are put together
    - and where the in-between layer stuff happens, like lifting the input to a higher dimension, and where the fnal output is projected down
    - in forward: if use_dse: our input x is shape (batchsize, da, nParticles), where da is the number of input channels/attributes per particle
    - we pull out the i-th quantity/attribute, so x[:, 0, :] is the x positions, for i=1 is the y positions... and the remaining
    - channels da > n_dims are the actual physical data, at each particle - so the first n_dims attributes are the positions of
    - particles in space!
